This modification changes the intensity and amount of wingflex to
better suit the real life 747-8i's wingflex

The default plane without this modification has a very minimal amount of wingflex.
This mod was balanced out by NickW to help the wingflex be more realistic and prevalent. 

PLEASE NOTE: This modification is experimental, so please keep a backup of your
flightmodel.cfg file elsewhere in the case it does not work. This mod will still continue 
to be patched given new information. 

Please sned any questions, concerns or data to the Reg Development discord server: https://discord.gg/G6NgfSh 
or contact the creator on discord @NickW#4545

Installation Instructions:
1. Open your main game directory
2. Go to asobo-aircraft-b7478i/simobjects/Airplanes/Asobo_B747_8i/...
3. Search for the flightmodel.cfg file and make a copy of it stored elsewhere
4. Drag and drop the modified flightmodel.cfg file where the original is, and when prompted press "replace files"
5. The wingflex adjustment mod should now work in game. Please make sure to restart the simulator.

Send any data, questions or concerns to https://discord.gg/G6NgfSh or @NickW#4545. 

Please note, this modification works only for making the 747-8i wingflex amount better. 
Do not try to use this on another aircraft or you may end up breaking it.